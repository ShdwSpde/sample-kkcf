# BootStrap Kente Cloth

A Pen created on CodePen.

Original URL: [https://codepen.io/mrmikespade/pen/NWVrBmm](https://codepen.io/mrmikespade/pen/NWVrBmm).

